package com.team.cinema.seat.dto;

import java.util.List;

public record ReservationRequest(Long screeningId, List<String> seatIds) {}
