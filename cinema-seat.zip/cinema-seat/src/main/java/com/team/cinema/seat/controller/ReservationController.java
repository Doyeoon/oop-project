package com.team.cinema.seat.controller;

import com.team.cinema.seat.dto.*;
import com.team.cinema.seat.service.ReservationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ReservationController {
    private final ReservationService service;

    public ReservationController(ReservationService service) { this.service = service; }

    @GetMapping("/screenings/{id}/seats")
    public List<SeatResponse> seats(@PathVariable Long id) {
        return service.getSeats(id).stream().map(SeatResponse::from).toList();
    }

    @PostMapping("/reservations")
    public ResponseEntity<ReservationResponse> reserve(@RequestBody ReservationRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ReservationResponse.from(service.reserve(req.screeningId(), req.seatIds())));
    }

    @GetMapping("/reservations/{id}")
    public ReservationResponse get(@PathVariable Long id) {
        return ReservationResponse.from(service.find(id));
    }

    @DeleteMapping("/reservations/{id}")
    public ReservationResponse cancel(@PathVariable Long id) {
        return ReservationResponse.from(service.cancel(id));
    }
}
