package com.team.cinema.seat.domain;

import java.util.List;

/** 예약 1건. 취소 시 좌석 해제까지 스스로 처리한다. */
public class Reservation {
    private final Long id;
    private final Screening screening;
    private final List<Seat> seats;
    private ReservationStatus status = ReservationStatus.CONFIRMED;

    public Reservation(Long id, Screening screening, List<Seat> seats) {
        this.id = id;
        this.screening = screening;
        this.seats = List.copyOf(seats);
    }

    public void cancel() {
        if (status == ReservationStatus.CANCELED)
            throw new IllegalStateException("이미 취소된 예약입니다.");
        seats.forEach(Seat::release);
        status = ReservationStatus.CANCELED;
    }

    /** 다형성: 좌석 종류와 무관하게 getSurcharge() 호출 */
    public int getTotalSurcharge() {
        return seats.stream().mapToInt(Seat::getSurcharge).sum();
    }

    public Long getId() { return id; }
    public Screening getScreening() { return screening; }
    public List<Seat> getSeats() { return seats; }
    public ReservationStatus getStatus() { return status; }
}
