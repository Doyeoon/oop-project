package com.team.cinema.seat.dto;

import com.team.cinema.seat.domain.Reservation;
import com.team.cinema.seat.domain.Seat;

import java.util.List;

public record ReservationResponse(Long id, Long screeningId, List<String> seatIds, int totalSurcharge, String status) {
    public static ReservationResponse from(Reservation r) {
        return new ReservationResponse(r.getId(), r.getScreening().getId(),
                r.getSeats().stream().map(Seat::getId).toList(),
                r.getTotalSurcharge(), r.getStatus().name());
    }
}
