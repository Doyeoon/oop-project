package com.team.cinema.seat;

import com.team.cinema.seat.domain.Reservation;
import com.team.cinema.seat.exception.*;
import com.team.cinema.seat.policy.*;
import com.team.cinema.seat.repository.InMemoryReservationRepository;
import com.team.cinema.seat.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ReservationServiceTest {
    ReservationService service;

    @BeforeEach
    void setUp() {
        service = new ReservationService(new InMemoryReservationRepository(),
                new InMemoryScreeningProvider(),
                List.of(new MaxSeatCountPolicy(3), new AdjacentSeatPolicy()));
    }

    @Test void 연속_좌석_예약_성공_및_추가요금_합산() {
        Reservation r = service.reserve(1L, List.of("E1", "E2"));
        assertEquals(6000, r.getTotalSurcharge());
    }

    @Test void 이미_예약된_좌석은_예외() {
        service.reserve(1L, List.of("A1"));
        assertThrows(SeatAlreadyReservedException.class, () -> service.reserve(1L, List.of("A1")));
    }

    @Test void 일부만_예약되지_않는다() {
        service.reserve(1L, List.of("A2"));
        assertThrows(SeatAlreadyReservedException.class, () -> service.reserve(1L, List.of("A1", "A2")));
        assertTrue(service.getSeats(1L).stream().filter(s -> s.getId().equals("A1")).findFirst().get().isAvailable());
    }

    @Test void 최대_좌석수_초과시_예외() {
        assertThrows(InvalidSeatSelectionException.class,
                () -> service.reserve(1L, List.of("A1", "A2", "A3", "A4")));
    }

    @Test void 연속되지_않은_좌석은_예외() {
        assertThrows(InvalidSeatSelectionException.class, () -> service.reserve(1L, List.of("A1", "A3")));
    }

    @Test void 취소하면_좌석이_풀린다() {
        Reservation r = service.reserve(1L, List.of("B1"));
        service.cancel(r.getId());
        assertDoesNotThrow(() -> service.reserve(1L, List.of("B1")));
    }

    @Test void 없는_예약_취소시_예외() {
        assertThrows(ReservationNotFoundException.class, () -> service.cancel(999L));
    }
}
