package com.team.cinema.seat;

import com.team.cinema.seat.domain.*;
import com.team.cinema.seat.exception.SeatAlreadyReservedException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SeatTest {
    @Test void 중복_예약하면_예외() {
        Seat s = new StandardSeat('A', 1);
        s.reserve();
        assertThrows(SeatAlreadyReservedException.class, s::reserve);
    }

    @Test void 해제하면_다시_예약_가능() {
        Seat s = new PremiumSeat('E', 1);
        s.reserve();
        s.release();
        assertTrue(s.isAvailable());
    }

    @Test void 좌석_종류별_추가요금() {
        assertEquals(0, new StandardSeat('A', 1).getSurcharge());
        assertEquals(3000, new PremiumSeat('E', 1).getSurcharge());
    }
}
