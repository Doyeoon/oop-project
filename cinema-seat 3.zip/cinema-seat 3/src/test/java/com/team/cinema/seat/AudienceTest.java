package com.team.cinema.seat;

import com.team.cinema.seat.domain.Audience;
import com.team.cinema.seat.domain.AudienceType;
import com.team.cinema.seat.exception.InvalidSeatSelectionException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AudienceTest {
    @Test void 유형별_인원과_합계() {
        Audience a = Audience.of(2, 1);
        assertEquals(2, a.getCount(AudienceType.ADULT));
        assertEquals(1, a.getCount(AudienceType.YOUTH));
        assertEquals(3, a.getTotal());
    }

    @Test void 인원이_0명이면_예외() {
        assertThrows(InvalidSeatSelectionException.class, () -> Audience.of(0, 0));
    }

    @Test void 최대_인원_초과시_예외() {
        assertThrows(InvalidSeatSelectionException.class, () -> Audience.of(5, 4));
    }

    @Test void 음수_인원은_예외() {
        assertThrows(InvalidSeatSelectionException.class, () -> Audience.of(-1, 2));
    }

    @Test void 좌석_수가_인원과_다르면_예외() {
        Audience a = Audience.of(1, 1);
        assertDoesNotThrow(() -> a.ensureSeatCount(2));
        assertThrows(InvalidSeatSelectionException.class, () -> a.ensureSeatCount(3));
    }
}
