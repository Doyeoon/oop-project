package com.team.cinema.seat.repository;

import com.team.cinema.seat.domain.Reservation;
import java.util.Optional;

public interface ReservationRepository {
    long nextId();
    Reservation save(Reservation reservation);
    Optional<Reservation> findById(Long id);
}
