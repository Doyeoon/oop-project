package com.team.cinema.seat.domain;

import com.team.cinema.seat.exception.InvalidSeatSelectionException;

import java.util.EnumMap;
import java.util.Map;

/** 관람 인원 구성(일반/청소년 인원수). 불변 객체이며 스스로 유효성을 검증한다. */
public class Audience {
    public static final int MAX_TOTAL = 8;

    private final Map<AudienceType, Integer> counts = new EnumMap<>(AudienceType.class);

    private Audience(int adult, int youth) {
        if (adult < 0 || youth < 0)
            throw new InvalidSeatSelectionException("관람 인원은 0명 이상이어야 합니다.");
        if (adult + youth == 0)
            throw new InvalidSeatSelectionException("관람 인원을 먼저 선택하세요.");
        if (adult + youth > MAX_TOTAL)
            throw new InvalidSeatSelectionException("관람 인원은 최대 " + MAX_TOTAL + "명까지 선택할 수 있습니다.");
        counts.put(AudienceType.ADULT, adult);
        counts.put(AudienceType.YOUTH, youth);
    }

    public static Audience of(int adult, int youth) { return new Audience(adult, youth); }

    public int getCount(AudienceType type) { return counts.getOrDefault(type, 0); }

    public int getTotal() { return counts.values().stream().mapToInt(Integer::intValue).sum(); }

    /** 선택한 좌석 수는 관람 인원과 같아야 한다. */
    public void ensureSeatCount(int seatCount) {
        if (seatCount != getTotal())
            throw new InvalidSeatSelectionException(
                    "관람 인원(" + getTotal() + "명)과 선택한 좌석 수(" + seatCount + "석)가 다릅니다.");
    }
}
