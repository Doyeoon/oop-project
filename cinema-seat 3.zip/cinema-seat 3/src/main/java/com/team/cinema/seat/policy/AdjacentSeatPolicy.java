package com.team.cinema.seat.policy;

import com.team.cinema.seat.domain.Seat;
import com.team.cinema.seat.exception.InvalidSeatSelectionException;
import java.util.Comparator;
import java.util.List;

/** 2석 이상 선택 시 같은 행의 연속된 좌석이어야 한다. */
public class AdjacentSeatPolicy implements SeatSelectionPolicy {
    @Override
    public void validate(List<Seat> selected) {
        if (selected.size() < 2) return;
        List<Seat> sorted = selected.stream().sorted(Comparator.comparingInt(Seat::getNumber)).toList();
        for (int i = 1; i < sorted.size(); i++) {
            Seat prev = sorted.get(i - 1), cur = sorted.get(i);
            if (prev.getRow() != cur.getRow() || cur.getNumber() != prev.getNumber() + 1)
                throw new InvalidSeatSelectionException("여러 좌석은 같은 행의 연속된 좌석만 선택할 수 있습니다.");
        }
    }
}
