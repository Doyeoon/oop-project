package com.team.cinema.seat.policy;

import com.team.cinema.seat.domain.Seat;
import com.team.cinema.seat.exception.InvalidSeatSelectionException;
import java.util.List;

public class MaxSeatCountPolicy implements SeatSelectionPolicy {
    private final int max;

    public MaxSeatCountPolicy(int max) { this.max = max; }

    @Override
    public void validate(List<Seat> selected) {
        if (selected.size() > max)
            throw new InvalidSeatSelectionException("최대 " + max + "석까지 예약할 수 있습니다.");
    }
}
