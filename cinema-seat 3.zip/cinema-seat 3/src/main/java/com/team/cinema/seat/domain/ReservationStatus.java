package com.team.cinema.seat.domain;

public enum ReservationStatus { CONFIRMED, CANCELED }
