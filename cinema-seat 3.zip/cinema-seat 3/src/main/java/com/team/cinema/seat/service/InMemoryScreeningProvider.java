package com.team.cinema.seat.service;

import com.team.cinema.seat.domain.*;
import com.team.cinema.seat.exception.ScreeningNotFoundException;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Map;

/** 단독 테스트용 임시 상영 데이터 (A~D행 일반석, E~F행 프리미엄석, 각 10열) */
@Component
public class InMemoryScreeningProvider implements ScreeningProvider {
    private final Map<Long, Screening> screenings;

    public InMemoryScreeningProvider() {
        SeatMap map = new SeatMap();
        for (char row = 'A'; row <= 'F'; row++) {
            for (int n = 1; n <= 10; n++) {
                map.add(row >= 'E' ? new PremiumSeat(row, n) : new StandardSeat(row, n));
            }
        }
        screenings = Map.of(1L, new Screening(1L, "테스트 영화", LocalDateTime.now().plusHours(3), map));
    }

    @Override
    public Screening get(Long id) {
        Screening s = screenings.get(id);
        if (s == null) throw new ScreeningNotFoundException(id);
        return s;
    }
}
