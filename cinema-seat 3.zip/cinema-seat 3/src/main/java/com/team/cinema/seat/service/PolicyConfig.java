package com.team.cinema.seat.service;

import com.team.cinema.seat.policy.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PolicyConfig {
    @Bean SeatSelectionPolicy maxSeatPolicy() { return new MaxSeatCountPolicy(8); }
    @Bean SeatSelectionPolicy adjacentPolicy() { return new AdjacentSeatPolicy(); }
}
