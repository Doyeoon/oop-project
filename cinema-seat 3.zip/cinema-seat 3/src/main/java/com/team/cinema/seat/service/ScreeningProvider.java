package com.team.cinema.seat.service;

import com.team.cinema.seat.domain.Screening;

/** 영화 선택 담당 파트와의 경계. 합칠 때 이 인터페이스 구현체만 교체한다. */
public interface ScreeningProvider {
    Screening get(Long screeningId);
}
