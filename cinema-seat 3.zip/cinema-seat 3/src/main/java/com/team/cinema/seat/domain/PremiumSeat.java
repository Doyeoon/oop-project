package com.team.cinema.seat.domain;

/** 리클라이너 등 프리미엄 좌석 */
public class PremiumSeat extends Seat {
    public PremiumSeat(char row, int number) { super(row, number); }
    @Override public int getSurcharge() { return 3000; }
    @Override public String getType() { return "PREMIUM"; }
}
