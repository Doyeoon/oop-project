package com.team.cinema.seat.dto;

import com.team.cinema.seat.domain.AudienceType;
import com.team.cinema.seat.domain.Reservation;
import com.team.cinema.seat.domain.Seat;

import java.util.List;

public record ReservationResponse(Long id, Long screeningId, List<String> seatIds,
                                  int adultCount, int youthCount, int totalSurcharge, String status) {
    public static ReservationResponse from(Reservation r) {
        return new ReservationResponse(r.getId(), r.getScreening().getId(),
                r.getSeats().stream().map(Seat::getId).toList(),
                r.getAudience().getCount(AudienceType.ADULT),
                r.getAudience().getCount(AudienceType.YOUTH),
                r.getTotalSurcharge(), r.getStatus().name());
    }
}
