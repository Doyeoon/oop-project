package com.team.cinema.seat.policy;

import com.team.cinema.seat.domain.Seat;
import java.util.List;

/** 좌석 선택 규칙 규약. 위반 시 InvalidSeatSelectionException 발생. */
public interface SeatSelectionPolicy {
    void validate(List<Seat> selected);
}
