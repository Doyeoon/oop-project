package com.team.cinema.seat.domain;

import com.team.cinema.seat.exception.SeatAlreadyReservedException;

/** 좌석 추상 클래스. 상태(status)는 private 으로 숨기고 reserve()/release() 로만 변경한다. */
public abstract class Seat {
    private final char row;
    private final int number;
    private SeatStatus status = SeatStatus.AVAILABLE;

    protected Seat(char row, int number) {
        this.row = row;
        this.number = number;
    }

    public String getId() { return "" + row + number; }
    public char getRow() { return row; }
    public int getNumber() { return number; }
    public boolean isAvailable() { return status == SeatStatus.AVAILABLE; }

    /** 좌석 스스로 상태 규칙을 검증한다. */
    public void reserve() {
        if (status != SeatStatus.AVAILABLE) throw new SeatAlreadyReservedException(getId());
        status = SeatStatus.RESERVED;
    }

    public void release() { status = SeatStatus.AVAILABLE; }

    /** 좌석 종류별 추가요금 (요금 담당 파트에서 합산) */
    public abstract int getSurcharge();

    /** 좌석 종류 이름 (화면 표시용) */
    public abstract String getType();
}
