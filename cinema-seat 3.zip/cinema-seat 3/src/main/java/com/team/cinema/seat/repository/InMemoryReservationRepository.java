package com.team.cinema.seat.repository;

import com.team.cinema.seat.domain.Reservation;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class InMemoryReservationRepository implements ReservationRepository {
    private final Map<Long, Reservation> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong();

    @Override public long nextId() { return sequence.incrementAndGet(); }
    @Override public Reservation save(Reservation r) { store.put(r.getId(), r); return r; }
    @Override public Optional<Reservation> findById(Long id) { return Optional.ofNullable(store.get(id)); }
}
