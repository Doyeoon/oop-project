package com.team.cinema.seat.exception;

public class ScreeningNotFoundException extends RuntimeException {
    public ScreeningNotFoundException(Long id) { super("상영 정보를 찾을 수 없습니다: " + id); }
}
