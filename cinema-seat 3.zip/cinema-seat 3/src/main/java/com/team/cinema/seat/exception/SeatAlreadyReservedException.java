package com.team.cinema.seat.exception;

public class SeatAlreadyReservedException extends RuntimeException {
    public SeatAlreadyReservedException(String seatId) { super("이미 예약된 좌석입니다: " + seatId); }
}
