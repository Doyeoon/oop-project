package com.team.cinema.seat.domain;

public class StandardSeat extends Seat {
    public StandardSeat(char row, int number) { super(row, number); }
    @Override public int getSurcharge() { return 0; }
    @Override public String getType() { return "STANDARD"; }
}
