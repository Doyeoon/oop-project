package com.team.cinema.seat.domain;

import com.team.cinema.seat.exception.InvalidSeatSelectionException;
import com.team.cinema.seat.exception.SeatAlreadyReservedException;
import com.team.cinema.seat.exception.SeatNotFoundException;

import java.util.*;

/** 상영관 좌석 배치. 좌석 조회와 일괄 예약(전부 성공 or 전부 실패)을 책임진다. */
public class SeatMap {
    private final Map<String, Seat> seats = new LinkedHashMap<>();

    public void add(Seat seat) { seats.put(seat.getId(), seat); }

    public List<Seat> findSeats(List<String> ids) {
        if (ids == null || ids.isEmpty())
            throw new InvalidSeatSelectionException("좌석을 한 개 이상 선택하세요.");
        if (new HashSet<>(ids).size() != ids.size())
            throw new InvalidSeatSelectionException("중복된 좌석이 있습니다.");
        return ids.stream()
                .map(id -> Optional.ofNullable(seats.get(id)).orElseThrow(() -> new SeatNotFoundException(id)))
                .toList();
    }

    /** 먼저 전부 검사한 뒤 예약하므로 중간에 실패해도 일부만 예약되지 않는다. */
    public void reserveAll(List<Seat> targets) {
        targets.forEach(s -> {
            if (!s.isAvailable()) throw new SeatAlreadyReservedException(s.getId());
        });
        targets.forEach(Seat::reserve);
    }

    public List<Seat> getAllSeats() { return List.copyOf(seats.values()); }
}
