package com.team.cinema.seat.service;

import com.team.cinema.seat.domain.*;
import com.team.cinema.seat.exception.ReservationNotFoundException;
import com.team.cinema.seat.policy.SeatSelectionPolicy;
import com.team.cinema.seat.repository.ReservationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/** 예약/취소 흐름만 조율한다. 규칙은 Seat, SeatMap, Policy 가 각자 책임진다. */
@Service
public class ReservationService {
    private final ReservationRepository repository;
    private final ScreeningProvider screeningProvider;
    private final List<SeatSelectionPolicy> policies;

    public ReservationService(ReservationRepository repository,
                              ScreeningProvider screeningProvider,
                              List<SeatSelectionPolicy> policies) {
        this.repository = repository;
        this.screeningProvider = screeningProvider;
        this.policies = policies;
    }

    public List<Seat> getSeats(Long screeningId) {
        return screeningProvider.get(screeningId).getSeatMap().getAllSeats();
    }

    public Reservation reserve(Long screeningId, List<String> seatIds, Audience audience) {
        Screening screening = screeningProvider.get(screeningId);
        SeatMap seatMap = screening.getSeatMap();
        synchronized (seatMap) {                       // 같은 상영관 동시 예약 방지
            List<Seat> seats = seatMap.findSeats(seatIds);
            audience.ensureSeatCount(seats.size());       // 관람 인원 = 좌석 수
            policies.forEach(p -> p.validate(seats));  // 다형성
            seatMap.reserveAll(seats);
            return repository.save(new Reservation(repository.nextId(), screening, seats, audience));
        }
    }

    public Reservation cancel(Long reservationId) {
        Reservation r = find(reservationId);
        synchronized (r.getScreening().getSeatMap()) {
            r.cancel();
            return repository.save(r);
        }
    }

    public Reservation find(Long id) {
        return repository.findById(id).orElseThrow(() -> new ReservationNotFoundException(id));
    }
}
