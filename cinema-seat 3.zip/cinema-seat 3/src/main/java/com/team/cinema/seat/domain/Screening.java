package com.team.cinema.seat.domain;

import java.time.LocalDateTime;

/** 상영 회차. (영화 선택 담당 파트와 합칠 때 이 클래스를 교체/확장) */
public class Screening {
    private final Long id;
    private final String movieTitle;
    private final LocalDateTime startTime;
    private final SeatMap seatMap;

    public Screening(Long id, String movieTitle, LocalDateTime startTime, SeatMap seatMap) {
        this.id = id;
        this.movieTitle = movieTitle;
        this.startTime = startTime;
        this.seatMap = seatMap;
    }

    public Long getId() { return id; }
    public String getMovieTitle() { return movieTitle; }
    public LocalDateTime getStartTime() { return startTime; }
    public SeatMap getSeatMap() { return seatMap; }
}
