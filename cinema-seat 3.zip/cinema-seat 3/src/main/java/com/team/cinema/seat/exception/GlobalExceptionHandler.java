package com.team.cinema.seat.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(SeatAlreadyReservedException.class)
    public ResponseEntity<Map<String, String>> conflict(RuntimeException e) { return body(HttpStatus.CONFLICT, e); }

    @ExceptionHandler({SeatNotFoundException.class, ReservationNotFoundException.class, ScreeningNotFoundException.class})
    public ResponseEntity<Map<String, String>> notFound(RuntimeException e) { return body(HttpStatus.NOT_FOUND, e); }

    @ExceptionHandler({InvalidSeatSelectionException.class, IllegalStateException.class})
    public ResponseEntity<Map<String, String>> badRequest(RuntimeException e) { return body(HttpStatus.BAD_REQUEST, e); }

    private ResponseEntity<Map<String, String>> body(HttpStatus s, RuntimeException e) {
        return ResponseEntity.status(s).body(Map.of("message", e.getMessage()));
    }
}
