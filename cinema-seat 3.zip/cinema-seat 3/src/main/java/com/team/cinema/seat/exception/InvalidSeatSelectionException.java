package com.team.cinema.seat.exception;

public class InvalidSeatSelectionException extends RuntimeException {
    public InvalidSeatSelectionException(String message) { super(message); }
}
