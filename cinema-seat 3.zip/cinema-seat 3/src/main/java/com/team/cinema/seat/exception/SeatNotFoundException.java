package com.team.cinema.seat.exception;

public class SeatNotFoundException extends RuntimeException {
    public SeatNotFoundException(String seatId) { super("존재하지 않는 좌석입니다: " + seatId); }
}
