package com.team.cinema.seat.domain;

public enum SeatStatus { AVAILABLE, RESERVED }
