package com.team.cinema.seat.domain;

/** 관람 인원 유형. 새 유형(우대 등)은 여기에 값만 추가하면 된다. */
public enum AudienceType {
    ADULT("일반"), YOUTH("청소년");

    private final String label;

    AudienceType(String label) { this.label = label; }

    public String getLabel() { return label; }
}
