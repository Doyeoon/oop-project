package com.team.cinema.seat.dto;

import com.team.cinema.seat.domain.Seat;

public record SeatResponse(String id, String row, int number, String type, boolean available, int surcharge) {
    public static SeatResponse from(Seat s) {
        return new SeatResponse(s.getId(), String.valueOf(s.getRow()), s.getNumber(),
                s.getType(), s.isAvailable(), s.getSurcharge());
    }
}
