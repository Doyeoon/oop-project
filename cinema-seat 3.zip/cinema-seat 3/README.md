# 영화관 좌석 예약 (좌석 예약 파트)

## 실행 방법
1. JDK 17 설치
2. 프로젝트 루트에서 `gradle wrapper` 실행(최초 1회) 후 `./gradlew bootRun`
   (IntelliJ에서 폴더를 Gradle 프로젝트로 열고 `CinemaApplication` 실행도 가능)
3. 브라우저에서 http://localhost:8080 접속
4. 테스트: `./gradlew test`

## API
| 메서드 | 경로 | 설명 |
|---|---|---|
| GET | /api/screenings/{id}/seats | 좌석 배치도 조회 |
| POST | /api/reservations | 좌석 예약 `{screeningId, seatIds}` |
| GET | /api/reservations/{id} | 예약 조회 |
| DELETE | /api/reservations/{id} | 예약 취소 |

## 폴더 구조
- `seat/domain` : Seat(추상), StandardSeat, PremiumSeat, SeatMap, Screening, Reservation
- `seat/policy` : SeatSelectionPolicy(인터페이스), MaxSeatCountPolicy, AdjacentSeatPolicy
- `seat/service` : ReservationService, ScreeningProvider(인터페이스), PolicyConfig
- `seat/repository` : ReservationRepository(인터페이스), InMemoryReservationRepository
- `seat/controller`, `seat/dto`, `seat/exception`

## OOP 적용 내용
- **은닉성**: `Seat.status`는 private, `reserve()/release()`로만 변경하며 중복 예약은 좌석이 스스로 예외 처리. `SeatMap`은 내부 Map을 노출하지 않고 불변 복사본만 반환. `Reservation.seats`도 불변 리스트.
- **상속성**: 공통 속성·상태 관리는 `Seat`, 종류별 차이(추가요금, 타입명)만 하위 클래스.
- **다형성**: `List<Seat>`에서 `getSurcharge()` 호출, `List<SeatSelectionPolicy>`를 순회하며 `validate()` 호출.
- **추상성**: `Seat`, `SeatSelectionPolicy`, `ReservationRepository`, `ScreeningProvider`. 새 좌석 유형은 `Seat` 하위 클래스 추가, 새 규칙은 Policy 구현체 + Bean 등록만으로 확장.

## 책임 분리
- Seat: 자기 상태 검증 / SeatMap: 좌석 조회·일괄 예약 / Policy: 선택 규칙 / Reservation: 총 추가요금·취소 / Service: 흐름 조율

## 팀 파트 연동
- 영화 선택 파트: `ScreeningProvider` 구현체를 교체하고 `Screening.getSeatMap()` 제공
- 요금 파트: `Reservation.getSeats()` / `getTotalSurcharge()` 사용

## 생성형 AI 활용 (작성 필요)
- 사용 도구: 
- 활용 수준(0~4단계): 
- 주요 활용 내용 / 직접 검토·수정한 부분: 

## 기능 테스트 결과 (작성 필요)
`./gradlew test` 결과와 화면 테스트 결과를 기록하세요.

## 설계 개선 내용 (작성 필요)
초기 설계 → 최종 설계 변경 사항과 이유를 기록하세요.

## 관람 인원 선택 (일반/청소년)
- 좌석 선택 전에 `Audience`(일반/청소년 인원, 최대 8명)를 먼저 선택한다.
- 선택한 좌석 수는 관람 인원과 같아야 예약할 수 있다 (`Audience.ensureSeatCount`).
- `POST /api/reservations` 요청에 `adultCount`, `youthCount` 추가. 응답에도 포함.
- 요금 파트: `Reservation.getAudience().getCount(AudienceType.ADULT / YOUTH)`로 유형별 인원 조회.
- 설계: `AudienceType`(enum) + `Audience`(불변 객체, 스스로 검증). 새 유형은 enum 값 추가로 확장.
